package org.arcctg;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.QuadCurve2D;
import javax.swing.JPanel;

public class TemplatePanel extends JPanel {

    protected static final int VERTEX_RADIUS = 20;
    protected static final double ARROW_SIZE = 10.0;
    protected static final int SELF_LOOP_OFFSET = 40;
    private static final int CURVE_CONTROL_OFFSET = 50;
    private int vertexCount;

    protected void drawGraph(Graphics2D g2d, int[][] matrix, Point center, Dimension dimension, boolean isDirected, boolean isCondensation) {
        vertexCount = matrix.length;
        int width = dimension.width;
        int height = dimension.height;

        int centerX = center.x + width / 2;
        int centerY = center.y + height / 2;

        int radius = Math.min(width, height) / 3;

        Point[] vertexPositions = calculateVertexPositions(centerX, centerY, radius);

        drawEdges(g2d, matrix, vertexPositions, isDirected);
        drawVertices(g2d, vertexPositions, isCondensation);
    }

    private Point[] calculateVertexPositions(int centerX, int centerY, int radius) {
        Point[] positions = new Point[vertexCount];

        positions[0] = new Point(centerX, centerY);

        double angleStep = 2 * Math.PI / (vertexCount - 1);
        for (int i = 1; i < vertexCount; i++) {
            int vx = centerX + (int) (radius * Math.cos((i - 1) * angleStep));
            int vy = centerY + (int) (radius * Math.sin((i - 1) * angleStep));
            positions[i] = new Point(vx, vy);
        }

        return positions;
    }

    private void drawEdges(Graphics2D g2d, int[][] matrix, Point[] vertexPositions, boolean isDirected) {
        boolean[][] bidirectionalEdges = findBidirectionalEdges(matrix, isDirected);

        for (int i = 0; i < vertexCount; i++) {
            for (int j = 0; j < vertexCount; j++) {
                if (matrix[i][j] == 1) {
                    boolean isBidirectional = bidirectionalEdges[i][j];
                    drawEdge(g2d, vertexPositions[i], vertexPositions[j], i, j, vertexPositions[0],
                        isDirected,
                        isBidirectional);
                }
            }
        }
    }

    private boolean[][] findBidirectionalEdges(int[][] matrix, boolean isDirected) {
        boolean[][] bidirectionalEdges = new boolean[vertexCount][vertexCount];

        if (isDirected) {
            for (int i = 0; i < vertexCount; i++) {
                for (int j = 0; j < vertexCount; j++) {
                    if (matrix[i][j] == 1 && matrix[j][i] == 1 && i != j) {
                        bidirectionalEdges[i][j] = true;
                        bidirectionalEdges[j][i] = true;
                    }
                }
            }
        }

        return bidirectionalEdges;
    }

    private void drawVertices(Graphics2D g2d, Point[] vertexPositions, boolean isCondensation) {
        for (int i = 0; i < vertexCount; i++) {
            if (isCondensation) {
                drawComponentVertex(g2d, vertexPositions[i], i + 1);
            } else {
                drawVertex(g2d, vertexPositions[i], i + 1);
            }
        }
    }

    private void drawVertex(Graphics2D g2d, Point position, int index) {
        g2d.setColor(Color.WHITE);
        Ellipse2D.Double circle = new Ellipse2D.Double(
            position.x - VERTEX_RADIUS,
            position.y - VERTEX_RADIUS,
            2.0 * VERTEX_RADIUS,
            2.0 * VERTEX_RADIUS
        );
        g2d.fill(circle);

        g2d.setColor(Color.BLACK);
        g2d.draw(circle);

        drawVertexLabel(g2d, position, index);
    }

    private void drawVertexLabel(Graphics2D g2d, Point position, int index) {
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        String label = String.valueOf(index);
        FontMetrics metrics = g2d.getFontMetrics();
        int labelWidth = metrics.stringWidth(label);
        int labelHeight = metrics.getHeight();

        g2d.drawString(
            label,
            position.x - labelWidth / 2,
            position.y + labelHeight / 4
        );
    }

    private void drawEdge(Graphics2D g2d, Point from, Point to, int fromIndex, int toIndex,
        Point centerPoint, boolean isDirected, boolean isBidirectional) {
        boolean throughCenter = fromIndex != 0 && toIndex != 0 && linePassesThroughCenter(from, to, centerPoint);

        if (fromIndex == toIndex) {
            drawSelfLoop(g2d, from, fromIndex);
        } else if (isBidirectional || throughCenter) {
            drawCurvedEdge(g2d, from, to, centerPoint, isDirected, isBidirectional);
        } else {
            drawStraightEdge(g2d, from, to, isDirected);
        }
    }

    private boolean linePassesThroughCenter(Point from, Point to, Point center) {
        double distance = distanceFromPointToLine(center, from, to);
        return distance < 2 * VERTEX_RADIUS;
    }

    private double distanceFromPointToLine(Point point, Point lineStart, Point lineEnd) {
        double numerator = Math.abs(
            (lineEnd.y - lineStart.y) * point.x -
                (lineEnd.x - lineStart.x) * point.y +
                lineEnd.x * lineStart.y -
                lineEnd.y * lineStart.x
        );

        double denominator = Math.sqrt(
            Math.pow(lineEnd.y - lineStart.y, 2) +
                Math.pow(lineEnd.x - lineStart.x, 2)
        );

        return numerator / denominator;
    }

    private void drawCurvedEdge(Graphics2D g2d, Point from, Point to, Point center, boolean isDirected,
        boolean isBidirectional) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double length = Math.sqrt(dx * dx + dy * dy);

        double perpX = -dy / length;
        double perpY = dx / length;

        double dotProduct = (center.x - from.x) * perpX + (center.y - from.y) * perpY;
        double sign = (dotProduct > 0) ? -1 : 1;
        int curveOffset = isBidirectional ? 12 : CURVE_CONTROL_OFFSET;

        double midX = (from.x + to.x) / 2.0;
        double midY = (from.y + to.y) / 2.0;
        int controlX = (int) (midX + sign * perpX * curveOffset);
        int controlY = (int) (midY + sign * perpY * curveOffset);

        double startAngle = Math.atan2(controlY - from.y, controlX - from.x);
        int startX = from.x + (int) (VERTEX_RADIUS * Math.cos(startAngle));
        int startY = from.y + (int) (VERTEX_RADIUS * Math.sin(startAngle));

        double endAngle = Math.atan2(controlY - to.y, controlX - to.x);
        int endX = to.x + (int) (VERTEX_RADIUS * Math.cos(endAngle));
        int endY = to.y + (int) (VERTEX_RADIUS * Math.sin(endAngle));

        g2d.draw(new QuadCurve2D.Double(startX, startY, controlX, controlY, endX, endY));

        if (isDirected) {
            double t = 0.95;
            double curvePointX = (1-t)*(1-t)*startX + 2*(1-t)*t*controlX + t*t*endX;
            double curvePointY = (1-t)*(1-t)*startY + 2*(1-t)*t*controlY + t*t*endY;

            drawArrow(g2d, (int)curvePointX, (int)curvePointY, endX, endY);
        }
    }

    private void drawSelfLoop(Graphics2D g2d, Point vertex, int vertexIndex) {
        double angleOffset = (vertexIndex == 0) ? Math.PI / 4 : getAngleForVertex(vertexIndex);

        int loopSize = VERTEX_RADIUS * 3;
        int offsetX = (int) (SELF_LOOP_OFFSET * Math.cos(angleOffset));
        int offsetY = (int) (SELF_LOOP_OFFSET * Math.sin(angleOffset));

        int loopX = vertex.x + offsetX - loopSize / 2;
        int loopY = vertex.y + offsetY - loopSize / 2;

        g2d.drawOval(loopX, loopY, loopSize, loopSize);
    }

    private double getAngleForVertex(int vertexIndex) {
        return vertexIndex == 0 ?
            Math.PI / 4 :
            2 * Math.PI * (vertexIndex - 1) / (vertexCount - 1);
    }

    protected void drawComponentVertex(Graphics2D g2d, Point position, int componentIndex) {
        g2d.setColor(new Color(173, 216, 230)); // Light blue
        Ellipse2D.Double circle = new Ellipse2D.Double(
            position.x - VERTEX_RADIUS * 1.0,
            position.y - VERTEX_RADIUS * 1.0,
            2.0 * VERTEX_RADIUS,
            2.0 * VERTEX_RADIUS
        );
        g2d.fill(circle);

        g2d.setColor(Color.BLACK);
        g2d.draw(circle);

        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        String label = "C" + componentIndex;
        FontMetrics metrics = g2d.getFontMetrics();
        int labelWidth = metrics.stringWidth(label);
        int labelHeight = metrics.getHeight();

        g2d.drawString(
            label,
            position.x - labelWidth / 2,
            position.y + labelHeight / 4
        );
    }

    protected void drawStraightEdge(Graphics2D g2d, Point from, Point to, boolean isDirected) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double length = Math.sqrt(dx * dx + dy * dy);

        double nx = dx / length;
        double ny = dy / length;

        int startX = from.x + (int) (nx * VERTEX_RADIUS);
        int startY = from.y + (int) (ny * VERTEX_RADIUS);
        int endX = to.x - (int) (nx * VERTEX_RADIUS);
        int endY = to.y - (int) (ny * VERTEX_RADIUS);

        g2d.setColor(Color.BLACK);
        g2d.draw(new Line2D.Double(startX, startY, endX, endY));

        if (isDirected) {
            drawArrow(g2d, startX, startY, endX, endY);
        }
    }

    protected void drawArrow(Graphics2D g2d, int x1, int y1, int x2, int y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double angle = Math.atan2(dy, dx);

        Path2D.Double path = new Path2D.Double();
        path.moveTo(x2, y2);
        path.lineTo(x2 - ARROW_SIZE * Math.cos(angle - Math.PI/6),
            y2 - ARROW_SIZE * Math.sin(angle - Math.PI/6));
        path.lineTo(x2 - ARROW_SIZE * Math.cos(angle + Math.PI/6),
            y2 - ARROW_SIZE * Math.sin(angle + Math.PI/6));
        path.closePath();

        g2d.fill(path);
    }
}
