package org.arcctg;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GraphTraversalApp app = new GraphTraversalApp();
            app.setVisible(true);
        });
    }
}