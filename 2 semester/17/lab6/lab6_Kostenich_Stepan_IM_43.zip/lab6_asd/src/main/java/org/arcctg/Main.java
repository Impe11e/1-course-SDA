package org.arcctg;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MinimumSpanningTree app = new MinimumSpanningTree();
            app.setVisible(true);
        });
    }
}