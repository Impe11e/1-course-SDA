package org.arcctg;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.util.List;
import java.util.Set;

public class CondensationGraphPanel extends TemplatePanel {

    private final int[][] condensationMatrix;
    private final List<Set<Integer>> stronglyConnectedComponents;

    public CondensationGraphPanel(int[][] condensationMatrix,
        List<Set<Integer>> stronglyConnectedComponents) {
        this.condensationMatrix = condensationMatrix;
        this.stronglyConnectedComponents = stronglyConnectedComponents;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = configureGraphics(g);

        drawTitle(g2d);
        drawCondensationGraph(g2d);
        drawComponentContents(g2d);
    }

    private Graphics2D configureGraphics(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setStroke(new BasicStroke(1.5f));
        return g2d;
    }

    private void drawTitle(Graphics2D g2d) {
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 20));
        g2d.drawString("Condensation Graph", getWidth() / 2 - 100, 30);
    }

    private void drawCondensationGraph(Graphics2D g2d) {
        Dimension graphSize = new Dimension(getWidth() - 100, getHeight() - 70);
        Point graphPosition = new Point(0, 50);
        drawGraph(g2d, condensationMatrix, graphPosition, graphSize, true, true);
    }

    private void drawComponentContents(Graphics2D g2d) {
        g2d.setFont(new Font("Arial", Font.PLAIN, 14));
        int y = getHeight() - 150;

        g2d.drawString("Component Contents:", 50, y);
        y += 20;

        for (int i = 0; i < stronglyConnectedComponents.size(); i++) {
            StringBuilder sb = new StringBuilder();
            sb.append("C").append(i + 1).append(": ");

            Set<Integer> component = stronglyConnectedComponents.get(i);
            for (int vertex : component) {
                sb.append(vertex + 1).append(" ");
            }

            g2d.drawString(sb.toString(), 50, y);
            y += 20;
        }
    }
}
