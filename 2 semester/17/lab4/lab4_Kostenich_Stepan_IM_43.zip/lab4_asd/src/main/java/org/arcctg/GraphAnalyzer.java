package org.arcctg;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class GraphAnalyzer extends JFrame {
    private static final int GROUP_NUMBER = 43;
    private static final int VARIANT_NUMBER = 17;
    private static final int VARIANT_CODE = GROUP_NUMBER * 100 + VARIANT_NUMBER;

    private static final int N3 = 1;
    private static final int N4 = 7;

    private static final int VERTEX_COUNT = 10 + N3;

    private static final double K1 = 1.0 - N3 * 0.01 - N4 * 0.01 - 0.3;
    private static final double K2 = 1.0 - N3 * 0.005 - N4 * 0.005 - 0.27;

    private static final int WINDOW_WIDTH = 1200;
    private static final int WINDOW_HEIGHT = 800;

    private int[][] directedMatrix1;
    private int[][] undirectedMatrix1;

    private int[][] directedMatrix2;
    private int[][] undirectedMatrix2;

    private int[][] reachabilityMatrix;
    private int[][] strongConnectivityMatrix;
    private List<Set<Integer>> stronglyConnectedComponents;
    private int[][] condensationMatrix;

    public GraphAnalyzer() {
        initializeWindow();
        generateMatrices();
        analyzeGraphs();
        setupUI();
    }

    private void initializeWindow() {
        setTitle("Graph Analyzer - Lab 4");
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void setupUI() {
        JTabbedPane tabbedPane = new JTabbedPane();

        addPart1GraphsTab(tabbedPane);
        JTextArea textOutputArea = addPart1AnalysisTab(tabbedPane);
        addPart3GraphsTab(tabbedPane);
        addPart3AnalysisTab(tabbedPane);
        addCondensationGraphTab(tabbedPane);

        add(tabbedPane);

        textOutputArea.setText(getFirstAnalysisText());
    }

    private void addPart1GraphsTab(JTabbedPane tabbedPane) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new GraphPanel(directedMatrix1, "Part 1 Visualization", false), BorderLayout.CENTER);
        tabbedPane.addTab("Part 1 Graphs", panel);
    }

    private JTextArea addPart1AnalysisTab(JTabbedPane tabbedPane) {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea(20, 40);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        panel.add(scrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Part 1-2 Analysis", panel);
        return textArea;
    }

    private void addPart3GraphsTab(JTabbedPane tabbedPane) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new GraphPanel(directedMatrix2, "Part 3 Visualization", false), BorderLayout.CENTER);
        tabbedPane.addTab("Part 3 Graphs", panel);
    }

    private void addPart3AnalysisTab(JTabbedPane tabbedPane) {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea(20, 40);
        textArea.setEditable(false);
        textArea.append(getSecondAnalysisText());
        JScrollPane scrollPane = new JScrollPane(textArea);
        panel.add(scrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Part 3-4 Analysis", panel);
    }

    private void addCondensationGraphTab(JTabbedPane tabbedPane) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new CondensationGraphPanel(condensationMatrix, stronglyConnectedComponents),
            BorderLayout.CENTER);
        tabbedPane.addTab("Condensation Graph", panel);
    }

    private void generateMatrices() {
        generatePart1and2Matrices();
        generatePart3and4Matrices();
        printDebugMatrices();
    }

    private void generatePart1and2Matrices() {
        directedMatrix1 = generateMatrix(K1);
        undirectedMatrix1 = generateUndirectedMatrix(directedMatrix1);
    }

    private void generatePart3and4Matrices() {
        directedMatrix2 = generateMatrix(K2);
        undirectedMatrix2 = generateUndirectedMatrix(directedMatrix2);
    }

    private void printDebugMatrices() {
        System.out.println("Part 1-2 Directed Graph Adjacency Matrix (K=" + K1 + "):");
        printMatrix(directedMatrix1);

        System.out.println("\nPart 1-2 Undirected Graph Adjacency Matrix:");
        printMatrix(undirectedMatrix1);

        System.out.println("\nPart 3-4 Directed Graph Adjacency Matrix (K=" + K2 + "):");
        printMatrix(directedMatrix2);

        System.out.println("\nPart 3-4 Undirected Graph Adjacency Matrix:");
        printMatrix(undirectedMatrix2);
    }

    private int[][] generateMatrix(double k) {
        Random random = new Random(VARIANT_CODE);
        int[][] resultMatrix = new int[VERTEX_COUNT][VERTEX_COUNT];

        for (int i = 0; i < VERTEX_COUNT; i++) {
            for (int j = 0; j < VERTEX_COUNT; j++) {
                double value = random.nextDouble(0.0, 2.0) * k;
                resultMatrix[i][j] = value >= 1.0 ? 1 : 0;
            }
        }

        return resultMatrix;
    }

    private int[][] generateUndirectedMatrix(int[][] directedMatrix) {
        int[][] resultMatrix = new int[VERTEX_COUNT][VERTEX_COUNT];

        for (int i = 0; i < VERTEX_COUNT; i++) {
            for (int j = 0; j < VERTEX_COUNT; j++) {
                if (directedMatrix[i][j] == 1) {
                    resultMatrix[i][j] = 1;
                    resultMatrix[j][i] = 1;
                }
            }
        }

        return resultMatrix;
    }

    private void analyzeGraphs() {
        calculateReachabilityMatrix();
        calculateStrongConnectivityMatrix();
        findStronglyConnectedComponents();
        buildCondensationGraph();
    }

    private void calculateReachabilityMatrix() {
        reachabilityMatrix = new int[VERTEX_COUNT][VERTEX_COUNT];

        initializeReachabilityMatrix();

        applyWarshallAlgorithm();
    }

    private void initializeReachabilityMatrix() {
        for (int i = 0; i < VERTEX_COUNT; i++) {
            System.arraycopy(directedMatrix2[i], 0, reachabilityMatrix[i], 0, VERTEX_COUNT);
            reachabilityMatrix[i][i] = 1;
        }
    }

    private void applyWarshallAlgorithm() {
        for (int k = 0; k < VERTEX_COUNT; k++) {
            for (int i = 0; i < VERTEX_COUNT; i++) {
                for (int j = 0; j < VERTEX_COUNT; j++) {
                    if (reachabilityMatrix[i][k] == 1 && reachabilityMatrix[k][j] == 1) {
                        reachabilityMatrix[i][j] = 1;
                    }
                }
            }
        }
    }

    private void calculateStrongConnectivityMatrix() {
        strongConnectivityMatrix = new int[VERTEX_COUNT][VERTEX_COUNT];

        for (int i = 0; i < VERTEX_COUNT; i++) {
            for (int j = 0; j < VERTEX_COUNT; j++) {
                if (reachabilityMatrix[i][j] == 1 && reachabilityMatrix[j][i] == 1) {
                    strongConnectivityMatrix[i][j] = 1;
                }
            }
        }
    }

    private void findStronglyConnectedComponents() {
        stronglyConnectedComponents = new ArrayList<>();
        boolean[] visited = new boolean[VERTEX_COUNT];

        for (int i = 0; i < VERTEX_COUNT; i++) {
            if (!visited[i]) {
                Set<Integer> component = new HashSet<>();
                component.add(i);
                visited[i] = true;

                for (int j = 0; j < VERTEX_COUNT; j++) {
                    if (j != i && !visited[j] && strongConnectivityMatrix[i][j] == 1) {
                        component.add(j);
                        visited[j] = true;
                    }
                }

                stronglyConnectedComponents.add(component);
            }
        }
    }

    private void buildCondensationGraph() {
        int componentCount = stronglyConnectedComponents.size();
        condensationMatrix = new int[componentCount][componentCount];

        for (int i = 0; i < componentCount; i++) {
            for (int j = 0; j < componentCount; j++) {
                if (i != j) {
                    condensationMatrix[i][j] = hasEdgeBetweenComponents(i, j);
                }
            }
        }
    }

    private int hasEdgeBetweenComponents(int fromComponentIndex, int toComponentIndex) {
        Set<Integer> fromComponent = stronglyConnectedComponents.get(fromComponentIndex);
        Set<Integer> toComponent = stronglyConnectedComponents.get(toComponentIndex);

        for (int vertexFrom : fromComponent) {
            if (hasEdgeFromVertexToComponent(vertexFrom, toComponent)) {
                return 1;
            }
        }
        return 0;
    }

    private boolean hasEdgeFromVertexToComponent(int vertexFrom, Set<Integer> toComponent) {
        for (int vertexTo : toComponent) {
            if (directedMatrix2[vertexFrom][vertexTo] == 1) {
                return true;
            }
        }
        return false;
    }

    private String getFirstAnalysisText() {
        StringBuilder sb = new StringBuilder();

        sb.append("PART 1-2 ANALYSIS (K = ").append(K1).append(")\n\n");

        int[] undirectedDegrees = calculateOutDegrees(undirectedMatrix1);
        int[] inDegrees = calculateInDegrees(directedMatrix1);
        int[] outDegrees = calculateOutDegrees(directedMatrix1);

        appendUndirectedDegreeInfo(sb, undirectedDegrees);
        appendDirectedDegreeInfo(sb, inDegrees, outDegrees);

        appendRegularityInfo(sb, undirectedDegrees, inDegrees, outDegrees);

        appendHangingVerticesInfo(sb, undirectedDegrees, "undirected graph");
        appendIsolatedVerticesInfo(sb, undirectedDegrees, "undirected graph");

        sb.append("\n");
        appendDirectedHangingVerticesInfo(sb, inDegrees, outDegrees);
        appendDirectedIsolatedVerticesInfo(sb, inDegrees, outDegrees);

        return sb.toString();
    }

    private void appendUndirectedDegreeInfo(StringBuilder sb, int[] degrees) {
        sb.append("Undirected Graph Vertex Degrees:\n");
        for (int i = 0; i < VERTEX_COUNT; i++) {
            sb.append("Vertex ").append(i + 1).append(": ").append(degrees[i]).append("\n");
        }
        sb.append("\n");
    }

    private void appendDirectedDegreeInfo(StringBuilder sb, int[] inDegrees, int[] outDegrees) {
        sb.append("Directed Graph In-Degrees and Out-Degrees:\n");
        for (int i = 0; i < VERTEX_COUNT; i++) {
            sb.append("Vertex ").append(i + 1).append(": in-degree = ").append(inDegrees[i])
                .append(", out-degree = ").append(outDegrees[i]).append("\n");
        }
        sb.append("\n");
    }

    private void appendRegularityInfo(StringBuilder sb, int[] undirectedDegrees, int[] inDegrees, int[] outDegrees) {
        sb.append("Regularity Check:\n");
        boolean isUndirectedRegular = isRegular(undirectedDegrees);
        boolean isDirectedRegular = isRegular(inDegrees) && isRegular(outDegrees);

        if (isUndirectedRegular) {
            sb.append("Undirected graph is regular with degree ").append(undirectedDegrees[0]).append("\n");
        } else {
            sb.append("Undirected graph is not regular\n");
        }

        if (isDirectedRegular) {
            sb.append("Directed graph is regular with in-degree ").append(inDegrees[0])
                .append(" and out-degree ").append(outDegrees[0]).append("\n");
        } else {
            sb.append("Directed graph is not regular\n");
        }
        sb.append("\n");
    }

    private void appendVerticesList(StringBuilder sb, List<Integer> vertices) {
        if (vertices.isEmpty()) {
            sb.append("none\n");
            return;
        }

        for (int vertex : vertices) {
            sb.append(vertex + 1).append(" ");
        }
        sb.append("\n");
    }

    private void appendHangingVerticesInfo(StringBuilder sb, int[] degrees, String graphType) {
        sb.append("Hanging vertices in ").append(graphType).append(": ");
        List<Integer> hangingVertices = findHangingVertices(degrees);
        appendVerticesList(sb, hangingVertices);
    }

    private void appendIsolatedVerticesInfo(StringBuilder sb, int[] degrees, String graphType) {
        sb.append("Isolated vertices in ").append(graphType).append(": ");
        List<Integer> isolatedVertices = findIsolatedVertices(degrees);
        appendVerticesList(sb, isolatedVertices);
    }

    private void appendDirectedHangingVerticesInfo(StringBuilder sb, int[] inDegrees, int[] outDegrees) {
        sb.append("Hanging vertices in directed graph: ");
        List<Integer> directedHangingVertices = findDirectedHangingVertices(inDegrees, outDegrees);
        appendVerticesList(sb, directedHangingVertices);
    }

    private void appendDirectedIsolatedVerticesInfo(StringBuilder sb, int[] inDegrees, int[] outDegrees) {
        sb.append("Isolated vertices in directed graph: ");
        List<Integer> directedIsolatedVertices = findDirectedIsolatedVertices(inDegrees, outDegrees);
        appendVerticesList(sb, directedIsolatedVertices);
    }

    private String getSecondAnalysisText() {
        StringBuilder sb = new StringBuilder();
        sb.append("PART 3-4 ANALYSIS (K = ").append(K2).append(")\n\n");

        appendDegreesInfo(sb);
        appendPathsInfo(sb);
        appendMatrixInfo(sb, "Reachability Matrix", reachabilityMatrix);
        appendMatrixInfo(sb, "Strong Connectivity Matrix", strongConnectivityMatrix);
        appendComponentsInfo(sb);

        return sb.toString();
    }

    private void appendDegreesInfo(StringBuilder sb) {
        sb.append("Directed Graph In-Degrees and Out-Degrees:\n");
        int[] inDegrees = calculateInDegrees(directedMatrix2);
        int[] outDegrees = calculateOutDegrees(directedMatrix2);

        for (int i = 0; i < VERTEX_COUNT; i++) {
            sb.append("Vertex ").append(i + 1)
                .append(": in-degree = ").append(inDegrees[i])
                .append(", out-degree = ").append(outDegrees[i])
                .append("\n");
        }
        sb.append("\n");
    }

    private void appendPathsInfo(StringBuilder sb) {
        int[][] paths2 = multiplyMatrices(directedMatrix2, directedMatrix2);
        appendPathsOfLength(sb, directedMatrix2, 2);

        int[][] paths3 = multiplyMatrices(paths2, directedMatrix2);
        appendPathsOfLength(sb, directedMatrix2, 3);
    }

    private void appendPathsOfLength(StringBuilder sb, int[][] matrix, int length) {
        sb.append("Paths of length ").append(length).append(":\n");
        List<String> pathsList = findPaths(matrix, length);

        for (String path : pathsList) {
            sb.append(path).append("\n");
        }
        sb.append("\n");
    }

    private void appendMatrixInfo(StringBuilder sb, String title, int[][] matrix) {
        sb.append(title).append(":\n");

        for (int i = 0; i < VERTEX_COUNT; i++) {
            for (int j = 0; j < VERTEX_COUNT; j++) {
                sb.append(matrix[i][j]).append(" ");
            }
            sb.append("\n");
        }
        sb.append("\n");
    }

    private void appendComponentsInfo(StringBuilder sb) {
        sb.append("Strongly Connected Components:\n");

        for (int i = 0; i < stronglyConnectedComponents.size(); i++) {
            sb.append("Component ").append(i + 1).append(": ");
            Set<Integer> component = stronglyConnectedComponents.get(i);

            for (int vertex : component) {
                sb.append(vertex + 1).append(" ");
            }
            sb.append("\n");
        }
    }

    private int[] calculateInDegrees(int[][] matrix) {
        int[] inDegrees = new int[VERTEX_COUNT];

        for (int j = 0; j < VERTEX_COUNT; j++) {
            int inDegree = 0;
            for (int i = 0; i < VERTEX_COUNT; i++) {
                inDegree += matrix[i][j];
            }
            inDegrees[j] = inDegree;
        }

        return inDegrees;
    }

    private int[] calculateOutDegrees(int[][] matrix) {
        int[] outDegrees = new int[VERTEX_COUNT];

        for (int i = 0; i < VERTEX_COUNT; i++) {
            int outDegree = 0;
            for (int j = 0; j < VERTEX_COUNT; j++) {
                outDegree += matrix[i][j];
            }
            outDegrees[i] = outDegree;
        }

        return outDegrees;
    }

    private boolean isRegular(int[] degrees) {
        if (degrees.length == 0) return true;

        int firstDegree = degrees[0];
        for (int i = 1; i < degrees.length; i++) {
            if (degrees[i] != firstDegree) {
                return false;
            }
        }

        return true;
    }

    private List<Integer> findHangingVertices(int[] degrees) {
        List<Integer> hangingVertices = new ArrayList<>();

        for (int i = 0; i < degrees.length; i++) {
            if (degrees[i] == 1) {
                hangingVertices.add(i);
            }
        }

        return hangingVertices;
    }

    private List<Integer> findIsolatedVertices(int[] degrees) {
        List<Integer> isolatedVertices = new ArrayList<>();

        for (int i = 0; i < degrees.length; i++) {
            if (degrees[i] == 0) {
                isolatedVertices.add(i);
            }
        }

        return isolatedVertices;
    }

    private List<Integer> findDirectedHangingVertices(int[] inDegrees, int[] outDegrees) {
        List<Integer> hangingVertices = new ArrayList<>();

        for (int i = 0; i < VERTEX_COUNT; i++) {
            if ((inDegrees[i] == 0 && outDegrees[i] == 1) || (inDegrees[i] == 1 && outDegrees[i] == 0)) {
                hangingVertices.add(i);
            }
        }

        return hangingVertices;
    }

    private List<Integer> findDirectedIsolatedVertices(int[] inDegrees, int[] outDegrees) {
        List<Integer> isolatedVertices = new ArrayList<>();

        for (int i = 0; i < VERTEX_COUNT; i++) {
            if (inDegrees[i] == 0 && outDegrees[i] == 0) {
                isolatedVertices.add(i);
            }
        }

        return isolatedVertices;
    }

    private int[][] multiplyMatrices(int[][] a, int[][] b) {
        int size = a.length;
        int[][] result = new int[size][size];

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                for (int k = 0; k < size; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }

        return result;
    }

    private List<String> findPaths(int[][] matrix, int length) {
        if (length == 2) {
            return findPathsOfLength2(matrix);
        } else if (length == 3) {
            return findPathsOfLength3(matrix);
        }
        return new ArrayList<>();
    }

    private List<String> findPathsOfLength2(int[][] matrix) {
        List<String> paths = new ArrayList<>();

        for (int i = 0; i < VERTEX_COUNT; i++) {
            for (int j = 0; j < VERTEX_COUNT; j++) {
                findIntermediateVertices(matrix, i, j, paths);
            }
        }

        return paths;
    }

    private void findIntermediateVertices(int[][] matrix, int start, int end, List<String> paths) {
        for (int intermediate = 0; intermediate < VERTEX_COUNT; intermediate++) {
            if (matrix[start][intermediate] == 1 && matrix[intermediate][end] == 1) {
                paths.add(formatPath(start, intermediate, end));
            }
        }
    }

    private List<String> findPathsOfLength3(int[][] matrix) {
        List<String> paths = new ArrayList<>();

        for (int i = 0; i < VERTEX_COUNT; i++) {
            for (int j = 0; j < VERTEX_COUNT; j++) {
                findTwoIntermediateVertices(matrix, i, j, paths);
            }
        }

        return paths;
    }

    private void findTwoIntermediateVertices(int[][] matrix, int start, int end, List<String> paths) {
        for (int first = 0; first < VERTEX_COUNT; first++) {
            for (int second = 0; second < VERTEX_COUNT; second++) {
                if (matrix[start][first] == 1 && matrix[first][second] == 1 && matrix[second][end] == 1) {
                    paths.add(formatPath(start, first, second, end));
                }
            }
        }
    }

    private String formatPath(int... vertices) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < vertices.length; i++) {
            sb.append(vertices[i] + 1);
            if (i < vertices.length - 1) {
                sb.append(" – ");
            }
        }
        return sb.toString();
    }

    private void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }
}