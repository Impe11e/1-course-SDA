package org.arcctg;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GraphAnalyzer app = new GraphAnalyzer();
            app.setVisible(true);
        });
    }
}