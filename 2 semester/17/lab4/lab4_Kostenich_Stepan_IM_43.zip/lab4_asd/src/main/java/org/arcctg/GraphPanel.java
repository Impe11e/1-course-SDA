package org.arcctg;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;

public class GraphPanel extends TemplatePanel {

    private final int[][] directed;
    private final String title;
    private final boolean isCondensation;

    public GraphPanel(int[][] directed, String title, boolean isCondensation) {
        this.directed = directed;
        this.title = title;
        this.isCondensation = isCondensation;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        configureGraphics(g2d);

        int panelWidth = getWidth();
        Dimension dimension = new Dimension(panelWidth / 2, getHeight());

        drawGraph(g2d, directed, new Point(0, 0), dimension, true, isCondensation);
        drawGraph(g2d, directed, new Point(panelWidth / 2, 0), dimension, false, isCondensation);

        drawTitles(g2d, panelWidth);
    }

    private void configureGraphics(Graphics2D g2d) {
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setStroke(new BasicStroke(1.5f));
    }

    private void drawTitles(Graphics2D g2d, int panelWidth) {
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 20));
        g2d.drawString(title + " - Directed Graph", 100, 30);
        g2d.drawString(title + " - Undirected Graph", panelWidth / 2 + 100, 30);
    }

}
